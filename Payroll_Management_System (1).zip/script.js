document.getElementById("payrollForm").addEventListener("submit", function(event) {
  event.preventDefault();
  const name = document.getElementById("empName").value;
  const basic = parseFloat(document.getElementById("basicSalary").value);
  const hra = basic * 0.2;
  const da = basic * 0.1;
  const total = basic + hra + da;
  document.getElementById("result").innerText = 
    `Employee: ${name}, Total Salary: ₹${total.toFixed(2)}`;
});
